// AJR Medical Imaging System - CBCT Functions
// Cone Beam CT specific functionality and 3D reconstruction

class CBCTProcessor {
    constructor() {
        this.projections = [];
        this.reconstructionVolume = null;
        this.sliceViews = {
            axial: null,
            coronal: null,
            sagittal: null,
            mip: null,
            vr: null
        };
        
        this.reconstructionParameters = {
            volumeSize: { x: 256, y: 256, z: 256 },
            voxelSize: 0.5, // mm
            reconstructionKernel: 'standard',
            filterType: 'ramp',
            sliceThickness: 1.0
        };
        
        this.currentSlice = {
            axial: 128,
            coronal: 128,
            sagittal: 128
        };
        
        this.initializeCBCT();
    }

    initializeCBCT() {
        this.setupReconstructionEngine();
        this.setupSliceNavigation();
        this.initializeVolume();
    }

    setupReconstructionEngine() {
        // Initialize WebGL-based reconstruction if available
        if (typeof WebGLRenderingContext !== 'undefined') {
            this.initializeWebGLReconstruction();
        }
        
        // Set up reconstruction pipeline
        this.reconstructionPipeline = [
            this.preprocessProjections.bind(this),
            this.applyFilter.bind(this),
            this.backproject.bind(this),
            this.postprocessVolume.bind(this)
        ];
    }

    initializeWebGLReconstruction() {
        // WebGL-based filtered back projection for performance
        const vertexShaderSource = `
            attribute vec2 a_position;
            attribute vec2 a_texCoord;
            uniform vec2 u_resolution;
            varying vec2 v_texCoord;
            
            void main() {
                vec2 clipSpace = ((a_position / u_resolution) * 2.0 - 1.0) * vec2(1, -1);
                gl_Position = vec4(clipSpace, 0, 1);
                v_texCoord = a_texCoord;
            }
        `;
        
        const fragmentShaderSource = `
            precision mediump float;
            uniform sampler2D u_projections;
            uniform sampler2D u_filter;
            uniform float u_angle;
            uniform vec2 u_resolution;
            varying vec2 v_texCoord;
            
            void main() {
                vec2 center = vec2(0.5, 0.5);
                vec2 coord = v_texCoord - center;
                
                // Rotate coordinate based on projection angle
                float cosAngle = cos(u_angle);
                float sinAngle = sin(u_angle);
                vec2 rotated = vec2(
                    coord.x * cosAngle - coord.y * sinAngle,
                    coord.x * sinAngle + coord.y * cosAngle
                );
                
                // Sample projection
                vec4 projection = texture2D(u_projections, rotated + center);
                
                // Apply filter
                vec4 filtered = projection * texture2D(u_filter, v_texCoord);
                
                gl_FragColor = filtered;
            }
        `;
        
        try {
            this.reconstructionCanvas = document.createElement('canvas');
            this.reconstructionCanvas.width = 512;
            this.reconstructionCanvas.height = 512;
            this.reconstructionGL = this.reconstructionCanvas.getContext('webgl');
            
            if (this.reconstructionGL) {
                this.setupReconstructionShaders(vertexShaderSource, fragmentShaderSource);
            }
        } catch (error) {
            console.warn('WebGL reconstruction initialization failed:', error);
        }
    }

    setupReconstructionShaders(vertexSource, fragmentSource) {
        // Implementation would create and compile shaders
        // This is a simplified version
        console.log('Reconstruction shaders initialized');
    }

    setupSliceNavigation() {
        // Set up crosshair navigation between views
        this.crosshairPosition = {
            x: 128,
            y: 128,
            z: 128
        };
        
        this.sliceNavigationEnabled = true;
    }

    initializeVolume() {
        // Create empty reconstruction volume
        const { x, y, z } = this.reconstructionParameters.volumeSize;
        this.reconstructionVolume = new Float32Array(x * y * z);
        
        // Initialize with zeros or filtered backprojection of first projection
        for (let i = 0; i < this.reconstructionVolume.length; i++) {
            this.reconstructionVolume[i] = 0;
        }
    }

    // Projection processing
    addProjection(projectionData, angle, parameters = {}) {
        const projection = {
            id: this.projections.length,
            angle: angle,
            data: projectionData,
            parameters: {
                kV: parameters.kV || 90,
                mA: parameters.mA || 5,
                ms: parameters.ms || 16,
                dose: parameters.dose || 0.005,
                ...parameters
            },
            timestamp: new Date()
        };
        
        this.projections.push(projection);
        
        // Update reconstruction in real-time if enabled
        if (this.realTimeReconstruction) {
            this.updateReconstruction(projection);
        }
        
        return projection;
    }

    preprocessProjections() {
        // Apply corrections to projections
        this.projections.forEach(projection => {
            // Dark current correction
            this.applyDarkCurrentCorrection(projection);
            
            // Flat field correction
            this.applyFlatFieldCorrection(projection);
            
            // Logarithmic transformation for attenuation
            this.applyLogarithmicTransform(projection);
            
            // Ring artifact removal
            this.removeRingArtifacts(projection);
        });
    }

    applyDarkCurrentCorrection(projection) {
        // Subtract dark current noise
        // In a real implementation, this would use calibrated dark current images
        const correctionFactor = 0.02; // Simulated dark current
        for (let i = 0; i < projection.data.length; i++) {
            projection.data[i] = Math.max(0, projection.data[i] - correctionFactor);
        }
    }

    applyFlatFieldCorrection(projection) {
        // Normalize by flat field (air scan)
        // In a real implementation, this would use calibrated flat field images
        const flatFieldValue = 1.0; // Simulated flat field
        for (let i = 0; i < projection.data.length; i++) {
            projection.data[i] = projection.data[i] / flatFieldValue;
        }
    }

    applyLogarithmicTransform(projection) {
        // Convert to attenuation values
        for (let i = 0; i < projection.data.length; i++) {
            projection.data[i] = -Math.log(Math.max(projection.data[i], 0.001));
        }
    }

    removeRingArtifacts(projection) {
        // Simple ring artifact removal using frequency domain filtering
        // This is a simplified version - real implementations are more complex
        const width = Math.sqrt(projection.data.length);
        const height = width;
        
        // Apply median filter in radial direction
        for (let y = 0; y < height; y++) {
            for (let x = 0; x < width; x++) {
                const centerX = width / 2;
                const centerY = height / 2;
                const radius = Math.sqrt(Math.pow(x - centerX, 2) + Math.pow(y - centerY, 2));
                
                // Apply correction based on radius
                const idx = y * width + x;
                projection.data[idx] *= (1 + 0.1 * Math.sin(radius * 0.1));
            }
        }
    }

    // Filter functions
    applyFilter() {
        const filterType = this.reconstructionParameters.filterType;
        
        switch (filterType) {
            case 'ramp':
                this.applyRampFilter();
                break;
            case 'shepp-logan':
                this.applySheppLoganFilter();
                break;
            case 'hamming':
                this.applyHammingFilter();
                break;
            default:
                this.applyRampFilter();
        }
    }

    applyRampFilter() {
        // Apply Ram-Lak (ramp) filter
        this.projections.forEach(projection => {
            const width = Math.sqrt(projection.data.length);
            const filtered = new Float32Array(projection.data.length);
            
            // Simple ramp filter implementation
            for (let x = 0; x < width; x++) {
                for (let y = 0; y < width; y++) {
                    const idx = y * width + x;
                    const freq = Math.abs(x - width / 2) / (width / 2);
                    filtered[idx] = projection.data[idx] * freq;
                }
            }
            
            projection.filteredData = filtered;
        });
    }

    applySheppLoganFilter() {
        // Apply Shepp-Logan filter (smoothed ramp)
        this.projections.forEach(projection => {
            const width = Math.sqrt(projection.data.length);
            const filtered = new Float32Array(projection.data.length);
            
            for (let x = 0; x < width; x++) {
                for (let y = 0; y < width; y++) {
                    const idx = y * width + x;
                    const freq = Math.abs(x - width / 2) / (width / 2);
                    const sheppLoganFactor = Math.sin(Math.PI * freq) / (Math.PI * freq + 0.001);
                    filtered[idx] = projection.data[idx] * freq * sheppLoganFactor;
                }
            }
            
            projection.filteredData = filtered;
        });
    }

    applyHammingFilter() {
        // Apply Hamming window filter
        this.projections.forEach(projection => {
            const width = Math.sqrt(projection.data.length);
            const filtered = new Float32Array(projection.data.length);
            
            for (let x = 0; x < width; x++) {
                for (let y = 0; y < width; y++) {
                    const idx = y * width + x;
                    const normalizedX = (x - width / 2) / (width / 2);
                    const hammingWindow = 0.54 + 0.46 * Math.cos(Math.PI * normalizedX);
                    filtered[idx] = projection.data[idx] * hammingWindow;
                }
            }
            
            projection.filteredData = filtered;
        });
    }

    // Backprojection
    backproject() {
        const { x, y, z } = this.reconstructionParameters.volumeSize;
        
        this.projections.forEach(projection => {
            const angle = projection.angle * Math.PI / 180;
            const cosAngle = Math.cos(angle);
            const sinAngle = Math.sin(angle);
            
            // Perform backprojection for this angle
            for (let k = 0; k < z; k++) {
                for (let j = 0; j < y; j++) {
                    for (let i = 0; i < x; i++) {
                        // Calculate coordinates in projection space
                        const xCoord = (i - x / 2) * this.reconstructionParameters.voxelSize;
                        const yCoord = (j - y / 2) * this.reconstructionParameters.voxelSize;
                        const zCoord = (k - z / 2) * this.reconstructionParameters.voxelSize;
                        
                        // Project onto detector plane
                        const detectorX = xCoord * cosAngle + yCoord * sinAngle;
                        const detectorY = zCoord;
                        
                        // Convert to image coordinates
                        const imgX = (detectorX / (this.reconstructionParameters.voxelSize * x)) * (Math.sqrt(projection.data.length) - 1) + Math.sqrt(projection.data.length) / 2;
                        const imgY = (detectorY / (this.reconstructionParameters.voxelSize * y)) * (Math.sqrt(projection.data.length) - 1) + Math.sqrt(projection.data.length) / 2;
                        
                        // Interpolate and add to volume
                        if (imgX >= 0 && imgX < Math.sqrt(projection.data.length) - 1 &&
                            imgY >= 0 && imgY < Math.sqrt(projection.data.length) - 1) {
                            
                            const value = this.bilinearInterpolate(
                                projection.filteredData || projection.data,
                                Math.sqrt(projection.data.length),
                                imgX,
                                imgY
                            );
                            
                            const volumeIndex = k * x * y + j * x + i;
                            this.reconstructionVolume[volumeIndex] += value;
                        }
                    }
                }
            }
        });
    }

    bilinearInterpolate(data, width, x, y) {
        const x1 = Math.floor(x);
        const y1 = Math.floor(y);
        const x2 = x1 + 1;
        const y2 = y1 + 1;
        
        const fx = x - x1;
        const fy = y - y1;
        
        const v11 = data[y1 * width + x1];
        const v12 = data[y2 * width + x1];
        const v21 = data[y1 * width + x2];
        const v22 = data[y2 * width + x2];
        
        const v1 = v11 * (1 - fx) + v21 * fx;
        const v2 = v12 * (1 - fx) + v22 * fx;
        
        return v1 * (1 - fy) + v2 * fy;
    }

    // Post-processing
    postprocessVolume() {
        // Apply post-reconstruction processing
        this.applyHUScaling();
        this.applyNoiseReduction();
        this.generateDerivedViews();
    }

    applyHUScaling() {
        // Convert to Hounsfield Units
        const waterAttenuation = 0.02; // Reference water attenuation
        const airAttenuation = 0.001;  // Reference air attenuation
        
        for (let i = 0; i < this.reconstructionVolume.length; i++) {
            const attenuation = this.reconstructionVolume[i];
            const hu = ((attenuation - waterAttenuation) / (waterAttenuation - airAttenuation)) * 1000;
            this.reconstructionVolume[i] = hu;
        }
    }

    applyNoiseReduction() {
        // Apply 3D median filter for noise reduction
        const { x, y, z } = this.reconstructionParameters.volumeSize;
        const filtered = new Float32Array(this.reconstructionVolume.length);
        
        for (let k = 1; k < z - 1; k++) {
            for (let j = 1; j < y - 1; j++) {
                for (let i = 1; i < x - 1; i++) {
                    const values = [];
                    
                    // 3x3x3 neighborhood
                    for (let dz = -1; dz <= 1; dz++) {
                        for (let dy = -1; dy <= 1; dy++) {
                            for (let dx = -1; dx <= 1; dx++) {
                                const idx = (k + dz) * x * y + (j + dy) * x + (i + dx);
                                values.push(this.reconstructionVolume[idx]);
                            }
                        }
                    }
                    
                    values.sort((a, b) => a - b);
                    filtered[k * x * y + j * x + i] = values[Math.floor(values.length / 2)];
                }
            }
        }
        
        this.reconstructionVolume = filtered;
    }

    generateDerivedViews() {
        // Generate MIP (Maximum Intensity Projection)
        this.generateMIP();
        
        // Generate VR (Volume Rendering)
        this.generateVolumeRendering();
    }

    generateMIP() {
        const { x, y, z } = this.reconstructionParameters.volumeSize;
        this.sliceViews.mip = {
            axial: new Float32Array(x * y),
            coronal: new Float32Array(x * z),
            sagittal: new Float32Array(y * z)
        };
        
        // Axial MIP
        for (let k = 0; k < z; k++) {
            for (let j = 0; j < y; j++) {
                for (let i = 0; i < x; i++) {
                    const idx = k * x * y + j * x + i;
                    const mipIdx = j * x + i;
                    this.sliceViews.mip.axial[mipIdx] = Math.max(
                        this.sliceViews.mip.axial[mipIdx] || -1000,
                        this.reconstructionVolume[idx]
                    );
                }
            }
        }
        
        // Coronal MIP
        for (let j = 0; j < y; j++) {
            for (let k = 0; k < z; k++) {
                for (let i = 0; i < x; i++) {
                    const idx = k * x * y + j * x + i;
                    const mipIdx = k * x + i;
                    this.sliceViews.mip.coronal[mipIdx] = Math.max(
                        this.sliceViews.mip.coronal[mipIdx] || -1000,
                        this.reconstructionVolume[idx]
                    );
                }
            }
        }
        
        // Sagittal MIP
        for (let i = 0; i < x; i++) {
            for (let k = 0; k < z; k++) {
                for (let j = 0; j < y; j++) {
                    const idx = k * x * y + j * x + i;
                    const mipIdx = k * y + j;
                    this.sliceViews.mip.sagittal[mipIdx] = Math.max(
                        this.sliceViews.mip.sagittal[mipIdx] || -1000,
                        this.reconstructionVolume[idx]
                    );
                }
            }
        }
    }

    generateVolumeRendering() {
        // Simplified volume rendering
        // In a real implementation, this would use ray casting or texture-based volume rendering
        const { x, y, z } = this.reconstructionParameters.volumeSize;
        
        this.sliceViews.vr = {
            axial: new Uint8Array(x * y * 4), // RGBA
            coronal: new Uint8Array(x * z * 4),
            sagittal: new Uint8Array(y * z * 4)
        };
        
        // Simple transfer function
        const transferFunction = (hu) => {
            if (hu < -100) return [0, 0, 0, 0]; // Air
            if (hu < 100) return [0.8, 0.8, 0.8, 0.3]; // Soft tissue
            if (hu < 300) return [0.9, 0.7, 0.5, 0.8]; // Bone
            return [1.0, 1.0, 1.0, 1.0]; // Dense bone
        };
        
        // Generate VR views (simplified)
        for (let view of ['axial', 'coronal', 'sagittal']) {
            const data = this.sliceViews[view === 'axial' ? 'mip' : 'vr'][view];
            const rgba = this.sliceViews.vr[view];
            
            for (let i = 0; i < data.length; i++) {
                const color = transferFunction(data[i]);
                rgba[i * 4] = Math.floor(color[0] * 255);
                rgba[i * 4 + 1] = Math.floor(color[1] * 255);
                rgba[i * 4 + 2] = Math.floor(color[2] * 255);
                rgba[i * 4 + 3] = Math.floor(color[3] * 255);
            }
        }
    }

    // Slice extraction and navigation
    getSlice(orientation, sliceIndex) {
        if (!this.reconstructionVolume) return null;
        
        const { x, y, z } = this.reconstructionParameters.volumeSize;
        let slice = null;
        
        switch (orientation) {
            case 'axial':
                slice = this.extractAxialSlice(sliceIndex);
                break;
            case 'coronal':
                slice = this.extractCoronalSlice(sliceIndex);
                break;
            case 'sagittal':
                slice = this.extractSagittalSlice(sliceIndex);
                break;
            default:
                slice = this.extractAxialSlice(sliceIndex);
        }
        
        return this.convertToImageData(slice, x, y);
    }

    extractAxialSlice(sliceIndex) {
        const { x, y, z } = this.reconstructionParameters.volumeSize;
        const slice = new Float32Array(x * y);
        
        for (let j = 0; j < y; j++) {
            for (let i = 0; i < x; i++) {
                const volumeIndex = sliceIndex * x * y + j * x + i;
                slice[j * x + i] = this.reconstructionVolume[volumeIndex];
            }
        }
        
        return slice;
    }

    extractCoronalSlice(sliceIndex) {
        const { x, y, z } = this.reconstructionParameters.volumeSize;
        const slice = new Float32Array(x * z);
        
        for (let k = 0; k < z; k++) {
            for (let i = 0; i < x; i++) {
                const volumeIndex = k * x * y + sliceIndex * x + i;
                slice[k * x + i] = this.reconstructionVolume[volumeIndex];
            }
        }
        
        return slice;
    }

    extractSagittalSlice(sliceIndex) {
        const { x, y, z } = this.reconstructionParameters.volumeSize;
        const slice = new Float32Array(y * z);
        
        for (let k = 0; k < z; k++) {
            for (let j = 0; j < y; j++) {
                const volumeIndex = k * x * y + j * x + sliceIndex;
                slice[k * y + j] = this.reconstructionVolume[volumeIndex];
            }
        }
        
        return slice;
    }

    convertToImageData(sliceData, width, height) {
        const imageData = new ImageData(width, height);
        
        // Convert HU values to grayscale
        for (let i = 0; i < sliceData.length; i++) {
            const hu = sliceData[i];
            let gray = 0;
            
            if (hu <= -1000) gray = 0; // Air
            else if (hu >= 1000) gray = 255; // Dense bone
            else gray = ((hu + 1000) / 2000) * 255; // Linear mapping
            
            imageData.data[i * 4] = gray;     // R
            imageData.data[i * 4 + 1] = gray; // G
            imageData.data[i * 4 + 2] = gray; // B
            imageData.data[i * 4 + 3] = 255;  // A
        }
        
        return imageData;
    }

    updateCrosshairPosition(x, y, z) {
        this.crosshairPosition = { x, y, z };
        
        if (this.sliceNavigationEnabled) {
            this.currentSlice.axial = Math.floor(z);
            this.currentSlice.coronal = Math.floor(y);
            this.currentSlice.sagittal = Math.floor(x);
            
            this.onSliceChanged();
        }
    }

    onSliceChanged() {
        // Notify UI components of slice changes
        if (typeof window !== 'undefined' && window.ajrSystem) {
            window.ajrSystem.logEvent('slice_navigation', {
                axial: this.currentSlice.axial,
                coronal: this.currentSlice.coronal,
                sagittal: this.currentSlice.sagittal
            });
        }
    }

    // Quality metrics
    calculateQualityMetrics() {
        if (!this.reconstructionVolume) return null;
        
        return {
            snr: this.calculateSNR(),
            cnr: this.calculateCNR(),
            spatialResolution: this.calculateSpatialResolution(),
            contrastResolution: this.calculateContrastResolution(),
            artifactScore: this.calculateArtifactScore()
        };
    }

    calculateSNR() {
        // Signal-to-noise ratio calculation
        const roiMean = this.calculateROIMean(100, 100, 50, 50);
        const backgroundStd = this.calculateBackgroundStd();
        
        return roiMean / backgroundStd;
    }

    calculateCNR() {
        // Contrast-to-noise ratio calculation
        const softTissueROI = this.calculateROIMean(120, 120, 30, 30);
        const backgroundROI = this.calculateROIMean(100, 100, 30, 30);
        const backgroundStd = this.calculateBackgroundStd();
        
        return Math.abs(softTissueROI - backgroundROI) / backgroundStd;
    }

    calculateROIMean(x, y, width, height) {
        let sum = 0;
        let count = 0;
        
        for (let j = y; j < y + height; j++) {
            for (let i = x; i < x + width; i++) {
                const idx = j * 256 + i; // Assuming 256x256 slices
                sum += this.reconstructionVolume[idx];
                count++;
            }
        }
        
        return sum / count;
    }

    calculateBackgroundStd() {
        // Calculate standard deviation of background region
        const backgroundROI = this.getBackgroundRegion();
        const mean = this.calculateROIMean(
            backgroundROI.x,
            backgroundROI.y,
            backgroundROI.width,
            backgroundROI.height
        );
        
        let sumSquaredDiff = 0;
        let count = 0;
        
        for (let j = backgroundROI.y; j < backgroundROI.y + backgroundROI.height; j++) {
            for (let i = backgroundROI.x; i < backgroundROI.x + backgroundROI.width; i++) {
                const idx = j * 256 + i;
                const diff = this.reconstructionVolume[idx] - mean;
                sumSquaredDiff += diff * diff;
                count++;
            }
        }
        
        return Math.sqrt(sumSquaredDiff / count);
    }

    getBackgroundRegion() {
        // Return coordinates of background region for noise calculation
        return { x: 10, y: 10, width: 50, height: 50 };
    }

    calculateSpatialResolution() {
        // Calculate spatial resolution using edge spread function
        // Simplified implementation
        return 0.5; // mm (based on reconstruction parameters)
    }

    calculateContrastResolution() {
        // Calculate contrast resolution
        // Simplified implementation
        return 10; // HU (based on reconstruction parameters)
    }

    calculateArtifactScore() {
        // Calculate artifact score based on various metrics
        // Lower score is better
        let score = 0;
        
        // Check for streak artifacts
        score += this.detectStreakArtifacts() * 0.3;
        
        // Check for ring artifacts
        score += this.detectRingArtifacts() * 0.3;
        
        // Check for motion artifacts
        score += this.detectMotionArtifacts() * 0.4;
        
        return Math.min(score, 1.0);
    }

    detectStreakArtifacts() {
        // Detect streak artifacts in reconstruction
        // Simplified implementation
        return 0.1;
    }

    detectRingArtifacts() {
        // Detect ring artifacts in reconstruction
        // Simplified implementation
        return 0.05;
    }

    detectMotionArtifacts() {
        // Detect motion artifacts in reconstruction
        // Simplified implementation
        return 0.15;
    }

    // Export functions
    exportReconstruction(format = 'dicom') {
        switch (format) {
            case 'dicom':
                return this.exportAsDICOM();
            case 'nifti':
                return this.exportAsNIFTI();
            case 'raw':
                return this.exportAsRaw();
            default:
                return this.exportAsDICOM();
        }
    }

    exportAsDICOM() {
        // Export reconstruction as DICOM series
        // This is a simplified implementation
        const slices = [];
        
        for (let k = 0; k < this.reconstructionParameters.volumeSize.z; k++) {
            const slice = this.extractAxialSlice(k);
            slices.push(slice);
        }
        
        return {
            format: 'dicom',
            slices: slices,
            parameters: this.reconstructionParameters,
            qualityMetrics: this.calculateQualityMetrics()
        };
    }

    exportAsNIFTI() {
        // Export reconstruction as NIFTI format
        return {
            format: 'nifti',
            volume: this.reconstructionVolume,
            parameters: this.reconstructionParameters,
            qualityMetrics: this.calculateQualityMetrics()
        };
    }

    exportAsRaw() {
        // Export reconstruction as raw data
        return {
            format: 'raw',
            volume: this.reconstructionVolume,
            parameters: this.reconstructionParameters
        };
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CBCTProcessor;
}

// Initialize CBCT processor globally
let cbctProcessor;

document.addEventListener('DOMContentLoaded', function() {
    try {
        cbctProcessor = new CBCTProcessor();
        window.cbctProcessor = cbctProcessor;
        
        console.log('CBCT Processor initialized successfully');
    } catch (error) {
        console.error('Failed to initialize CBCT Processor:', error);
    }
});